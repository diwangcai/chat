import { test } from '@playwright/test'

test('聊天功能测试', async ({ page: _page }) => {
  // TODO: 实现聊天功能测试
})


